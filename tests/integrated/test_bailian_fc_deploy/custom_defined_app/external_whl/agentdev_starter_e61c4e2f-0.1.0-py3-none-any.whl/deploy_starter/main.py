import asyncio
import os
import yaml
import uvicorn
from contextlib import asynccontextmanager
from fastapi import FastAPI
from agentscope_runtime.engine import Runner
from agentscope_runtime.engine.agents.llm_agent import LLMAgent
from agentscope_runtime.engine.llms import QwenLLM
from agentscope_runtime.engine.schemas.agent_schemas import AgentRequest
from agentscope_runtime.engine.services.context_manager import ContextManager

# 读取config.yml文件
def read_config():
    config_path = os.path.join(os.path.dirname(__file__), 'config.yml')
    with open(config_path, 'r') as f:
        return yaml.safe_load(f)

# 读取配置
config = read_config()

# 初始化全局变量
runner = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    global runner
    # Startup
    # 检查是否配置了DASHSCOPE_API_KEY
    api_key = config.get('DASHSCOPE_API_KEY') or os.getenv("DASHSCOPE_API_KEY")
    
    if api_key:
        # 设置语言模型和智能体
        model = QwenLLM(
            model_name=config.get('DASHSCOPE_MODEL_NAME', 'qwen-turbo'),
            api_key=api_key,
        )
        llm_agent = LLMAgent(model=model, name="llm_agent")

        # 创建上下文管理器和运行器
        context_manager = ContextManager()
        await context_manager.__aenter__()
        runner = Runner(agent=llm_agent, context_manager=context_manager)
    else:
        # 如果没有API密钥，设置runner为None，但允许应用启动
        print("Warning: DASHSCOPE_API_KEY not configured. LLM features will be disabled.")
        runner = None
    
    yield
    
    # Shutdown
    if runner and runner.context_manager:
        await runner.context_manager.__aexit__(None, None, None)

app = FastAPI(
    title=config.get('APP_NAME', 'AgentDev Starter'),
    debug=config.get('DEBUG', False),
    lifespan=lifespan
)

@app.get("/")
def read_root():
    return {"hi agentDev"}

@app.get("/health")
def health_check():
    return "OK"



#百炼示例chat调用接口，需配置DASHSCOPE_API_KEY
@app.get("/chat")
async def chat(message: str):
    global runner
    if runner is None:
        return {"error": "LLM features are disabled due to missing DASHSCOPE_API_KEY configuration"}
    
    # 创建请求
    request = AgentRequest(
        input=[
            {
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": message,
                    },
                ],
            },
        ],
    )
    
    # 收集流式响应
    response_text = ""

    async for message in runner.stream_query(request=request):
        if hasattr(message, "text"):
            response_text += message.text
    
    return {"response": response_text}

def run_app():
    """运行FastAPI应用"""
    uvicorn.run(
        "deploy_starter.main:app",
        # 百炼云端部署端口号需要保留FC_START_HOST 0.0.0.0，本地测试127.0.0.1
        host=config.get('FC_START_HOST', '127.0.0.1'),
        port=config.get('PORT', 8080),
        reload=config.get('RELOAD', True)
    )

if __name__ == '__main__':
    run_app()